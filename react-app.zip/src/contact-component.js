import React from 'react';

export class ContactComponent extends React.Component{
	render(){
		return (
				<div className="container well">
					<p> gsdfgsdfgsdg </p>
				</div>
			)
		}
	}	