import React from 'react';

export class AboutComponent extends React.Component{
	render(){
		return (
				<div className="container well">
					<p> XYZ </p>
				</div>
			)
		}
	}	